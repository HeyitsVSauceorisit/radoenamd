package com.example.redstonescanner;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RedstoneScannerClient implements ClientModInitializer {
    private static final String MOD_ID = "redstonescanner";

    private static final int RADIUS = 150;
    private static final int SCAN_INTERVAL_TICKS = 20; // once per second
    private static final int MAX_HOTSPOT_LINES = 8;
    private static final int[] THRESHOLDS = {1, 3, 5, 10, 20};

    // Components to detect. Index order matches TYPE_NAMES.
    private static final Block[] TYPES = {
            Blocks.REPEATER, Blocks.COMPARATOR, Blocks.REDSTONE_WIRE, Blocks.OBSERVER, Blocks.CRAFTER
    };
    private static final String[] TYPE_NAMES = {
            "Repeater", "Comparator", "Dust", "Observer", "Crafter"
    };

    // ARGB colors (26.x text rendering needs the alpha byte)
    private static final int COLOR_TITLE = 0xFFFF5555;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_DIM = 0xFFAAAAAA;

    private static KeyMapping toggleKey;
    private static KeyMapping thresholdKey;
    private static boolean enabled = true;
    private static int thresholdIndex = 1; // default: hotspots with 3+ components
    private static int tickCounter = 0;

    private static volatile List<Hotspot> hotspots = new ArrayList<>();
    private static volatile int[] totals = new int[TYPES.length];

    /** All components found inside one chunk column. */
    private static class Hotspot {
        int count;
        long sumX, sumY, sumZ;
        final int[] perType = new int[TYPES.length];
        double distance;

        void add(int type, BlockPos p) {
            count++;
            perType[type]++;
            sumX += p.getX();
            sumY += p.getY();
            sumZ += p.getZ();
        }

        int avgX() { return (int) (sumX / count); }
        int avgY() { return (int) (sumY / count); }
        int avgZ() { return (int) (sumZ / count); }
    }

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "main"));

        toggleKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.redstonescanner.toggle", InputConstants.Type.KEYSYM,
                InputConstants.KEY_R, category));
        thresholdKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.redstonescanner.threshold", InputConstants.Type.KEYSYM,
                InputConstants.KEY_V, category));

        ClientTickEvents.END_CLIENT_TICK.register(RedstoneScannerClient::onTick);

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "hud"),
                RedstoneScannerClient::extractHud);
    }

    private static void onTick(Minecraft client) {
        while (toggleKey.consumeClick()) {
            enabled = !enabled;
            if (client.player != null) {
                client.player.sendSystemMessage(
                        Component.literal("Redstone Scanner: " + (enabled ? "ON" : "OFF")));
            }
            if (!enabled) {
                hotspots = new ArrayList<>();
                totals = new int[TYPES.length];
            }
        }
        while (thresholdKey.consumeClick()) {
            thresholdIndex = (thresholdIndex + 1) % THRESHOLDS.length;
            if (client.player != null) {
                client.player.sendSystemMessage(Component.literal(
                        "Redstone Scanner: min components per chunk = " + THRESHOLDS[thresholdIndex]));
            }
        }

        if (!enabled || client.player == null || client.level == null) return;

        if (++tickCounter >= SCAN_INTERVAL_TICKS) {
            tickCounter = 0;
            scan(client.level, client.player.blockPosition());
        }
    }

    private static int typeIndex(BlockState state) {
        for (int i = 0; i < TYPES.length; i++) {
            if (state.is(TYPES[i])) return i;
        }
        return -1;
    }

    private static boolean isTarget(BlockState state) {
        return typeIndex(state) >= 0;
    }

    /** Scans every loaded chunk within RADIUS, full height (underground, surface, sky). */
    private static void scan(ClientLevel level, BlockPos origin) {
        Map<Long, Hotspot> map = new HashMap<>();
        int[] newTotals = new int[TYPES.length];
        long radiusSq = (long) RADIUS * RADIUS;

        int minCX = (origin.getX() - RADIUS) >> 4;
        int maxCX = (origin.getX() + RADIUS) >> 4;
        int minCZ = (origin.getZ() - RADIUS) >> 4;
        int maxCZ = (origin.getZ() + RADIUS) >> 4;

        for (int cx = minCX; cx <= maxCX; cx++) {
            for (int cz = minCZ; cz <= maxCZ; cz++) {
                // Only returns chunks the server has actually sent to this client
                ChunkAccess chunk = level.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false);
                if (chunk == null) continue;

                long key = ((long) cx << 32) | (cz & 0xFFFFFFFFL);
                LevelChunkSection[] sections = chunk.getSections();

                for (int i = 0; i < sections.length; i++) {
                    LevelChunkSection section = sections[i];
                    if (section == null || section.hasOnlyAir()) continue;
                    // Fast palette check: skip sections that contain none of the targets
                    if (!section.maybeHas(RedstoneScannerClient::isTarget)) continue;

                    int baseY = chunk.getMinY() + (i << 4);
                    for (int x = 0; x < 16; x++) {
                        for (int y = 0; y < 16; y++) {
                            for (int z = 0; z < 16; z++) {
                                int type = typeIndex(section.getBlockState(x, y, z));
                                if (type < 0) continue;

                                BlockPos pos = new BlockPos((cx << 4) + x, baseY + y, (cz << 4) + z);
                                if (pos.distSqr(origin) > radiusSq) continue;

                                map.computeIfAbsent(key, k -> new Hotspot()).add(type, pos);
                                newTotals[type]++;
                            }
                        }
                    }
                }
            }
        }

        List<Hotspot> list = new ArrayList<>(map.values());
        for (Hotspot h : list) {
            double dx = h.avgX() - origin.getX();
            double dy = h.avgY() - origin.getY();
            double dz = h.avgZ() - origin.getZ();
            h.distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        }
        list.sort(Comparator.comparingDouble(h -> h.distance));

        hotspots = list;
        totals = newTotals;
    }

    private static void extractHud(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        Minecraft client = Minecraft.getInstance();
        if (!enabled || client.player == null) return;

        int minCount = THRESHOLDS[thresholdIndex];
        int x = 6, y = 6;

        StringBuilder sb = new StringBuilder("Redstone (" + RADIUS + "b): ");
        int[] t = totals;
        for (int i = 0; i < TYPES.length; i++) {
            sb.append(TYPE_NAMES[i]).append(' ').append(t[i]);
            if (i < TYPES.length - 1) sb.append(" | ");
        }
        graphics.text(client.font, sb.toString(), x, y, COLOR_TITLE, true);
        y += 10;
        graphics.text(client.font,
                "Hotspots (min " + minCount + "/chunk) - R toggle, V threshold",
                x, y, COLOR_DIM, true);

        BlockPos me = client.player.blockPosition();
        int shown = 0, hidden = 0;
        for (Hotspot h : hotspots) {
            if (h.count < minCount) continue;
            if (shown >= MAX_HOTSPOT_LINES) { hidden++; continue; }

            int dy = h.avgY() - me.getY();
            String vertical = dy > 5 ? " ^above" : dy < -5 ? " vbelow" : "";

            StringBuilder types = new StringBuilder();
            for (int i = 0; i < TYPES.length; i++) {
                if (h.perType[i] > 0) {
                    if (types.length() > 0) types.append(' ');
                    types.append(TYPE_NAMES[i].charAt(0)).append(h.perType[i]);
                }
            }

            y += 10;
            String line = h.avgX() + " " + h.avgY() + " " + h.avgZ()
                    + "  [" + (int) h.distance + "m]  x" + h.count
                    + " (" + types + ")" + vertical;
            graphics.text(client.font, line, x, y, COLOR_TEXT, true);
            shown++;
        }
        if (hidden > 0) {
            y += 10;
            graphics.text(client.font, "+" + hidden + " more hotspots", x, y, COLOR_DIM, true);
        }
        if (shown == 0 && hidden == 0) {
            y += 10;
            graphics.text(client.font, "None found", x, y, COLOR_DIM, true);
        }
    }
}
